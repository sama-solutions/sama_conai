/* ========================================= */
/* SAMA CONAI - DASHBOARD CLIENT ACTION     */
/* ========================================= */

odoo.define('sama_conai.dashboard_client_action', function (require) {
    'use strict';

    var AbstractAction = require('web.AbstractAction');
    var core = require('web.core');
    var rpc = require('web.rpc');
    var session = require('web.session');

    var _t = core._t;

    /**
     * Client Action pour le dashboard neumorphique SAMA CONAI
     */
    var SamaConaiDashboard = AbstractAction.extend({
        template: 'sama_conai.dashboard_client_action',
        
        events: {
            'click .nav-item': '_onNavigationClick',
            'click .metric-card': '_onMetricClick',
            'click .theme-choice-card': '_onThemeChange',
            'click .refresh-dashboard': '_onRefreshDashboard',
        },

        init: function(parent, action) {
            this._super.apply(this, arguments);
            this.dashboardData = {};
            this.chart = null;
        },

        willStart: function() {
            var self = this;
            return this._super().then(function() {
                return self._loadDashboardData();
            });
        },

        start: function() {
            var self = this;
            return this._super().then(function() {
                self._renderDashboard();
                self._initializeChart();
                self._initializeTheme();
                self._startAutoRefresh();
            });
        },

        destroy: function() {
            if (this.chart) {
                this.chart.destroy();
            }
            if (this.refreshInterval) {
                clearInterval(this.refreshInterval);
            }
            this._super.apply(this, arguments);
        },

        /**
         * Charge les données du dashboard depuis le serveur
         */
        _loadDashboardData: function() {
            var self = this;
            return rpc.query({
                route: '/sama_conai/dashboard/data',
                params: {}
            }).then(function(data) {
                self.dashboardData = data;
                return data;
            }).catch(function(error) {
                console.error('Erreur lors du chargement des données:', error);
                self._showNotification(_t('Erreur lors du chargement des données'), 'danger');
            });
        },

        /**
         * Rend le dashboard avec les données
         */
        _renderDashboard: function() {
            var self = this;
            var $dashboard = this.$('.sama-conai-dashboard');
            
            if ($dashboard.length === 0) {
                $dashboard = $('<div class="sama-conai-dashboard">').appendTo(this.$el);
            }

            // Rendu du header
            this._renderHeader($dashboard);
            
            // Rendu des métriques
            this._renderMetrics($dashboard);
            
            // Rendu du graphique
            this._renderChart($dashboard);
            
            // Rendu des tâches prioritaires
            this._renderPriorityTasks($dashboard);
            
            // Rendu de la navigation
            this._renderNavigation($dashboard);

            // Animation d'entrée
            this._animateCards();
        },

        /**
         * Rend le header du dashboard
         */
        _renderHeader: function($container) {
            var headerHtml = `
                <div class="dashboard-header">
                    <h1>Tableau de Bord</h1>
                    <div class="header-actions">
                        <button class="neumorphic-button refresh-dashboard" title="Actualiser">
                            <i class="fa fa-refresh"></i>
                        </button>
                        <div class="user-profile-icon" title="${this.dashboardData.user_name}">
                            <i class="fa fa-user"></i>
                        </div>
                    </div>
                </div>
            `;
            $container.append(headerHtml);
        },

        /**
         * Rend les cartes de métriques
         */
        _renderMetrics: function($container) {
            var metricsHtml = `
                <div class="metrics-grid">
                    <div class="neumorphic-card metric-card" data-action="in_progress">
                        <div class="metric-content">
                            <div class="metric-title">Demandes en Cours</div>
                            <div class="metric-value">${this.dashboardData.in_progress_count}</div>
                        </div>
                        <div class="metric-icon">
                            <i class="fa fa-file-text-o"></i>
                        </div>
                    </div>
                    
                    <div class="neumorphic-card metric-card" data-action="overdue">
                        <div class="metric-content">
                            <div class="metric-title">Dossiers en Retard</div>
                            <div class="metric-value" style="color: var(--accent-danger);">${this.dashboardData.overdue_count}</div>
                        </div>
                        <div class="metric-icon" style="color: var(--accent-danger);">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                    </div>
                </div>
            `;
            $container.append(metricsHtml);
        },

        /**
         * Rend le conteneur du graphique
         */
        _renderChart: function($container) {
            var chartHtml = `
                <div class="neumorphic-card chart-container">
                    <div class="chart-title">Répartition des Demandes</div>
                    <canvas id="dashboardChart" width="400" height="200"></canvas>
                    <div class="chart-total" style="text-align: center; margin-top: 1rem;">
                        <span style="font-size: 2rem; font-weight: bold; color: var(--text-color);">
                            ${this.dashboardData.total_requests}
                        </span>
                        <div style="font-size: 0.9rem; color: var(--text-color); opacity: 0.7;">
                            Total des demandes
                        </div>
                    </div>
                </div>
            `;
            $container.append(chartHtml);
        },

        /**
         * Rend la liste des tâches prioritaires
         */
        _renderPriorityTasks: function($container) {
            var tasksHtml = '<div class="priority-list"><div class="list-title">Mes Tâches Prioritaires</div>';
            
            if (this.dashboardData.priority_tasks && this.dashboardData.priority_tasks.length > 0) {
                this.dashboardData.priority_tasks.forEach(function(task) {
                    tasksHtml += `
                        <div class="neumorphic-card list-item" data-task-id="${task.id}" data-task-type="${task.type}">
                            <div class="status-bar" style="background-color: ${task.urgency_color}"></div>
                            <div class="item-content">
                                <div class="item-id">${task.reference}</div>
                                <div class="item-title">${task.subject}</div>
                            </div>
                        </div>
                    `;
                });
            } else {
                // Données par défaut
                tasksHtml += `
                    <div class="neumorphic-card list-item">
                        <div class="status-bar" style="background-color: var(--accent-danger)"></div>
                        <div class="item-content">
                            <div class="item-id">REQ-2025-001</div>
                            <div class="item-title">Demande d'accès aux documents budgétaires 2024</div>
                        </div>
                    </div>
                `;
            }
            
            tasksHtml += '</div>';
            $container.append(tasksHtml);
        },

        /**
         * Rend la navigation en bas
         */
        _renderNavigation: function($container) {
            var navHtml = `
                <nav class="bottom-nav neumorphic-nav">
                    <a href="#" class="nav-item active" data-section="dashboard" title="Tableau de Bord">
                        <i class="fa fa-tachometer"></i>
                    </a>
                    <a href="#" class="nav-item" data-section="requests" title="Demandes">
                        <i class="fa fa-file-text"></i>
                    </a>
                    <a href="#" class="nav-item" data-section="alerts" title="Alertes">
                        <i class="fa fa-bell"></i>
                    </a>
                    <a href="#" class="nav-item" data-section="profile" title="Profil">
                        <i class="fa fa-user"></i>
                    </a>
                </nav>
            `;
            $container.append(navHtml);
        },

        /**
         * Initialise le graphique Chart.js
         */
        _initializeChart: function() {
            var self = this;
            var ctx = this.$('#dashboardChart')[0];
            
            if (ctx && typeof Chart !== 'undefined') {
                var chartData = {
                    labels: ['En cours', 'Terminées', 'En retard', 'Nouvelles'],
                    datasets: [{
                        data: [
                            this.dashboardData.chart_data.in_progress,
                            this.dashboardData.chart_data.completed,
                            this.dashboardData.chart_data.overdue,
                            this.dashboardData.chart_data.new
                        ],
                        backgroundColor: [
                            'var(--chart-color-1)',
                            'var(--chart-color-4)',
                            'var(--chart-color-3)',
                            'var(--chart-color-2)'
                        ],
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                };

                this.chart = new Chart(ctx, {
                    type: 'doughnut',
                    data: chartData,
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    padding: 20,
                                    usePointStyle: true,
                                    font: {
                                        family: 'Poppins',
                                        size: 12
                                    }
                                }
                            }
                        },
                        cutout: '60%',
                        animation: {
                            animateRotate: true,
                            duration: 1000
                        }
                    }
                });
            }
        },

        /**
         * Initialise le système de thèmes
         */
        _initializeTheme: function() {
            // Applique le thème de l'utilisateur
            if (this.dashboardData.user_theme) {
                document.body.setAttribute('data-theme', this.dashboardData.user_theme);
            }
        },

        /**
         * Démarre l'actualisation automatique
         */
        _startAutoRefresh: function() {
            var self = this;
            this.refreshInterval = setInterval(function() {
                self._refreshMetrics();
            }, 300000); // Actualise toutes les 5 minutes
        },

        /**
         * Actualise uniquement les métriques
         */
        _refreshMetrics: function() {
            var self = this;
            return rpc.query({
                route: '/sama_conai/dashboard/metrics',
                params: {}
            }).then(function(metrics) {
                // Met à jour les valeurs affichées
                self.$('.metric-card[data-action="in_progress"] .metric-value').text(metrics.in_progress_count);
                self.$('.metric-card[data-action="overdue"] .metric-value').text(metrics.overdue_count);
                
                // Met à jour le graphique si nécessaire
                if (self.chart) {
                    self.chart.data.datasets[0].data = [
                        metrics.in_progress_count,
                        metrics.completed_requests,
                        metrics.overdue_count,
                        metrics.new_requests
                    ];
                    self.chart.update();
                }
            });
        },

        /**
         * Animation d'entrée pour les cartes
         */
        _animateCards: function() {
            this.$('.neumorphic-card').each(function(index, card) {
                $(card).css({
                    'opacity': '0',
                    'transform': 'translateY(20px)'
                });
                
                setTimeout(function() {
                    $(card).css({
                        'transition': 'all 0.5s ease-out',
                        'opacity': '1',
                        'transform': 'translateY(0)'
                    });
                }, index * 100);
            });
        },

        /**
         * Gestionnaire de clic sur la navigation
         */
        _onNavigationClick: function(ev) {
            ev.preventDefault();
            var $target = $(ev.currentTarget);
            var section = $target.data('section');
            
            // Met à jour l'état actif
            this.$('.nav-item').removeClass('active');
            $target.addClass('active');
            
            // Animation de feedback
            $target.css('transform', 'scale(0.95)');
            setTimeout(function() {
                $target.css('transform', '');
            }, 150);
            
            // Navigation selon la section
            this._navigateToSection(section);
        },

        /**
         * Gestionnaire de clic sur les métriques
         */
        _onMetricClick: function(ev) {
            var $target = $(ev.currentTarget);
            var action = $target.data('action');
            
            if (action === 'in_progress') {
                this._openAction('sama_conai.action_dashboard_requests_in_progress');
            } else if (action === 'overdue') {
                this._openAction('sama_conai.action_dashboard_requests_overdue');
            }
        },

        /**
         * Gestionnaire de changement de thème
         */
        _onThemeChange: function(ev) {
            var $target = $(ev.currentTarget);
            var themeName = $target.data('theme-name');
            
            if (themeName) {
                this._changeTheme(themeName);
            }
        },

        /**
         * Gestionnaire d'actualisation du dashboard
         */
        _onRefreshDashboard: function(ev) {
            ev.preventDefault();
            var self = this;
            
            // Animation de rotation
            var $icon = $(ev.currentTarget).find('i');
            $icon.addClass('fa-spin');
            
            this._loadDashboardData().then(function() {
                self._renderDashboard();
                if (self.chart) {
                    self.chart.destroy();
                }
                self._initializeChart();
                $icon.removeClass('fa-spin');
                self._showNotification(_t('Dashboard actualisé'), 'success');
            });
        },

        /**
         * Navigation vers une section
         */
        _navigateToSection: function(section) {
            switch(section) {
                case 'requests':
                    this._openAction('sama_conai.action_information_request_neumorphic');
                    break;
                case 'alerts':
                    this._openAction('sama_conai.action_whistleblowing_alert');
                    break;
                case 'profile':
                    this._openAction('sama_conai.action_user_theme_preferences');
                    break;
                case 'dashboard':
                default:
                    // Reste sur le dashboard
                    break;
            }
        },

        /**
         * Change le thème de l'utilisateur
         */
        _changeTheme: function(themeName) {
            var self = this;
            
            return rpc.query({
                route: '/sama_conai/theme/change',
                params: { theme_name: themeName }
            }).then(function(result) {
                if (result.success) {
                    document.body.setAttribute('data-theme', themeName);
                    self._showNotification(_t('Thème mis à jour'), 'success');
                } else {
                    self._showNotification(_t('Erreur lors du changement de thème'), 'danger');
                }
            });
        },

        /**
         * Ouvre une action Odoo
         */
        _openAction: function(actionXmlId) {
            this.do_action(actionXmlId);
        },

        /**
         * Affiche une notification
         */
        _showNotification: function(message, type) {
            this.displayNotification({
                title: _t('SAMA CONAI'),
                message: message,
                type: type || 'info',
                sticky: false,
            });
        }
    });

    // Enregistrement de l'action client
    core.action_registry.add('sama_conai_dashboard', SamaConaiDashboard);

    return SamaConaiDashboard;
});

/* ========================================= */
/* TEMPLATE QWEB POUR L'ACTION CLIENT       */
/* ========================================= */

// Le template sera défini dans un fichier XML séparé