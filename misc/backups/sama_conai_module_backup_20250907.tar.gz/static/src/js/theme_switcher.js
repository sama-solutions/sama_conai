/* SAMA CONAI - Theme Switcher minimal */
console.log('SAMA CONAI Theme Switcher loaded');