# -*- coding: utf-8 -*-

from odoo import http, fields
from odoo.http import request
import json
import logging

_logger = logging.getLogger(__name__)

class SamaConaiDashboardController(http.Controller):
    
    @http.route('/web/dataset/call_kw/sama_conai_dashboard', type='json', auth='user')
    def sama_conai_dashboard(self, **kwargs):
        """Contrôleur pour le dashboard neumorphique SAMA CONAI"""
        try:
            # Récupérer les données du dashboard
            dashboard_data = self._get_dashboard_data()
            
            return {
                'success': True,
                'data': dashboard_data,
                'theme': request.env.user.sama_conai_theme or 'institutionnel'
            }
        except Exception as e:
            _logger.error(f"Erreur dashboard SAMA CONAI: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    @http.route('/web/dataset/call_kw/public_transparency_dashboard', type='json', auth='user')
    def public_transparency_dashboard(self, **kwargs):
        """Contrôleur pour le tableau de bord public dans le backend"""
        try:
            # Récupérer les données publiques
            public_data = self._get_public_dashboard_data()
            
            return {
                'success': True,
                'data': public_data,
                'is_public': True
            }
        except Exception as e:
            _logger.error(f"Erreur dashboard public: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _get_dashboard_data(self):
        """Récupérer les données du dashboard"""
        user = request.env.user
        
        # Statistiques des demandes d'information
        info_requests = request.env['request.information']
        total_requests = info_requests.search_count([])
        user_requests = info_requests.search_count([('user_id', '=', user.id)])
        pending_requests = info_requests.search_count([
            ('user_id', '=', user.id),
            ('state', 'in', ['submitted', 'in_progress', 'pending_validation'])
        ])
        completed_requests = info_requests.search_count([
            ('user_id', '=', user.id),
            ('state', 'in', ['responded', 'refused'])
        ])
        overdue_requests = info_requests.search_count([
            ('user_id', '=', user.id),
            ('is_overdue', '=', True)
        ])
        
        # Demandes récentes de l'utilisateur
        recent_requests = info_requests.search([
            ('user_id', '=', user.id)
        ], limit=5, order='request_date desc')
        
        recent_requests_data = []
        for req in recent_requests:
            recent_requests_data.append({
                'id': req.id,
                'name': req.name,
                'description': req.description,
                'partner_name': req.partner_name,
                'state': req.state,
                'state_label': dict(req._fields['state'].selection)[req.state],
                'request_date': req.request_date.isoformat() if req.request_date else None,
                'deadline_date': req.deadline_date.isoformat() if req.deadline_date else None,
                'is_overdue': req.is_overdue,
                'days_to_deadline': req.days_to_deadline
            })
        
        # Statistiques des alertes
        alerts = request.env['whistleblowing.alert']
        total_alerts = alerts.search_count([])
        user_alerts = alerts.search_count([('manager_id', '=', user.id)])
        active_alerts = alerts.search_count([
            ('manager_id', '=', user.id),
            ('state', 'in', ['new', 'preliminary_assessment', 'investigation'])
        ])
        urgent_alerts = alerts.search_count([
            ('manager_id', '=', user.id),
            ('priority', '=', 'urgent')
        ])
        
        # Statistiques publiques
        avg_response_time = self._calculate_avg_response_time()
        success_rate = self._calculate_success_rate()
        
        return {
            'user_info': {
                'name': user.name,
                'email': user.email or user.login,
                'isAdmin': user.has_group('base.group_system')
            },
            'user_stats': {
                'total_requests': user_requests,
                'pending_requests': pending_requests,
                'completed_requests': completed_requests,
                'overdue_requests': overdue_requests
            },
            'recent_requests': recent_requests_data,
            'public_stats': {
                'total_public_requests': total_requests,
                'avg_response_time': avg_response_time,
                'success_rate': success_rate
            },
            'alert_stats': {
                'total_alerts': user_alerts,
                'active_alerts': active_alerts,
                'urgent_alerts': urgent_alerts,
                'new_alerts': alerts.search_count([
                    ('manager_id', '=', user.id),
                    ('state', '=', 'new')
                ])
            }
        }
    
    def _get_public_dashboard_data(self):
        """Récupérer les données du dashboard public"""
        # Statistiques globales
        info_requests = request.env['request.information']
        alerts = request.env['whistleblowing.alert']
        
        total_requests = info_requests.search_count([])
        responded_requests = info_requests.search_count([('state', '=', 'responded')])
        pending_requests = info_requests.search_count([('state', 'in', ['submitted', 'in_progress'])])
        
        total_alerts = alerts.search_count([])
        resolved_alerts = alerts.search_count([('state', '=', 'resolved')])
        
        # Répartition par état
        states_data = []
        for state, label in info_requests._fields['state'].selection:
            count = info_requests.search_count([('state', '=', state)])
            if count > 0:
                states_data.append({
                    'state': state,
                    'label': label,
                    'count': count
                })
        
        # Répartition par catégorie d'alertes
        categories_data = []
        for category, label in alerts._fields['category'].selection:
            count = alerts.search_count([('category', '=', category)])
            if count > 0:
                categories_data.append({
                    'category': category,
                    'label': label,
                    'count': count
                })
        
        return {
            'global_stats': {
                'total_requests': total_requests,
                'responded_requests': responded_requests,
                'pending_requests': pending_requests,
                'total_alerts': total_alerts,
                'resolved_alerts': resolved_alerts,
                'success_rate': round((responded_requests / total_requests * 100), 1) if total_requests > 0 else 0,
                'avg_response_time': self._calculate_avg_response_time()
            },
            'states_distribution': states_data,
            'categories_distribution': categories_data,
            'monthly_evolution': self._get_monthly_evolution()
        }
    
    def _calculate_avg_response_time(self):
        """Calculer le temps de réponse moyen"""
        try:
            requests = request.env['request.information'].search([
                ('state', '=', 'responded'),
                ('response_date', '!=', False),
                ('request_date', '!=', False)
            ])
            
            if not requests:
                return 0
            
            total_days = 0
            count = 0
            
            for req in requests:
                if req.request_date and req.response_date:
                    delta = req.response_date - req.request_date
                    total_days += delta.days
                    count += 1
            
            return round(total_days / count, 1) if count > 0 else 0
        except Exception:
            return 0
    
    def _calculate_success_rate(self):
        """Calculer le taux de succès"""
        try:
            total = request.env['request.information'].search_count([])
            responded = request.env['request.information'].search_count([('state', '=', 'responded')])
            
            return round((responded / total * 100), 1) if total > 0 else 0
        except Exception:
            return 0
    
    def _get_monthly_evolution(self):
        """Récupérer l'évolution mensuelle"""
        try:
            # Récupérer les données des 6 derniers mois
            from datetime import datetime, timedelta
            from dateutil.relativedelta import relativedelta
            
            end_date = datetime.now()
            start_date = end_date - relativedelta(months=6)
            
            monthly_data = []
            current_date = start_date
            
            while current_date <= end_date:
                month_start = current_date.replace(day=1)
                next_month = month_start + relativedelta(months=1)
                
                requests_count = request.env['request.information'].search_count([
                    ('request_date', '>=', month_start),
                    ('request_date', '<', next_month)
                ])
                
                alerts_count = request.env['whistleblowing.alert'].search_count([
                    ('alert_date', '>=', month_start),
                    ('alert_date', '<', next_month)
                ])
                
                monthly_data.append({
                    'month': current_date.strftime('%Y-%m'),
                    'month_label': current_date.strftime('%B %Y'),
                    'requests': requests_count,
                    'alerts': alerts_count
                })
                
                current_date = next_month
            
            return monthly_data
        except Exception:
            return []