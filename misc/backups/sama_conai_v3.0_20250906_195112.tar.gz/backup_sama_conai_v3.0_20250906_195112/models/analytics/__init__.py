# -*- coding: utf-8 -*-

from . import executive_dashboard
from . import auto_report_generator
from . import predictive_analytics