#!/usr/bin/env bash
set -euo pipefail

# Startup helper for the SAMA CONAI Odoo module (no Docker)
# It can create/update/run an Odoo instance pointing to this module.
#
# Requirements:
# - A local Odoo 18 environment (source or packaged)
# - PostgreSQL user (default: odoo)
#
# You can point to your odoo binary with env ODOO_BIN or --odoo-bin 
# You can point to official addons path with env ODOO_ADDONS
#
# Examples:
#   ./start_sama_conai.sh --help
#   ./start_sama_conai.sh --dry-run --init -d sama_conai_dev
#   ODOO_BIN=~/src/odoo/odoo-bin ODOO_ADDONS=~/src/odoo/odoo/addons ./start_sama_conai.sh --update -d sama_conai_dev

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULE_DIR="$SCRIPT_DIR"
CUSTOM_ADDONS_DIR="$(dirname "$MODULE_DIR")"
CONF_DIR="$MODULE_DIR/.odoo_local"
CONF_FILE="$CONF_DIR/odoo.conf"

ODBR="odoo"
DB_NAME="sama_conai_dev"
PORT="8069"
ACTION="run"   # run | init | update
DRY_RUN="false"
WITH_DEMO="false"
ODOO_BIN_CMD="${ODOO_BIN:-}"
ODOO_ADDONS_PATH="${ODOO_ADDONS:-}"

print_help() {
  cat <<EOF
Usage: $0 [options]

Options:
  -d, --db NAME           Nom de la base de données (défaut: ${DB_NAME})
  -p, --port PORT         Port HTTP Odoo (défaut: ${PORT})
  --init                  Installe le module (et dépendances) dans la base
  --update                Met à jour le module dans la base
  --run                   Lance le serveur sans installer/mettre à jour (défaut)
  --with-demo             Ne pas désactiver les données de démonstration
  --odoo-bin PATH         Chemin vers odoo-bin/odoo (sinon tentative d'auto-détection)
  --addons PATH           Chemin des addons officiels (fallback à env ODOO_ADDONS)
  --dry-run               Affiche la commande qui serait exécutée, sans lancer Odoo
  -h, --help              Affiche cette aide

Variables d'environnement utiles:
  ODOO_BIN      Chemin vers le binaire Odoo
  ODOO_ADDONS   Chemin vers les addons officiels d'Odoo

Exemples:
  $0 --init -d sama_conai_dev
  ODOO_BIN=~/src/odoo/odoo-bin ODOO_ADDONS=~/src/odoo/odoo/addons $0 --update -d sama_conai_dev
EOF
}

# Parse args
while [[ $# -gt 0 ]]; do
  case "$1" in
    -d|--db)
      DB_NAME="$2"; shift 2;
      ;;
    -p|--port)
      PORT="$2"; shift 2;
      ;;
    --init)
      ACTION="init"; shift 1;
      ;;
    --update)
      ACTION="update"; shift 1;
      ;;
    --run)
      ACTION="run"; shift 1;
      ;;
    --with-demo)
      WITH_DEMO="true"; shift 1;
      ;;
    --odoo-bin)
      ODOO_BIN_CMD="$2"; shift 2;
      ;;
    --addons)
      ODOO_ADDONS_PATH="$2"; shift 2;
      ;;
    --dry-run)
      DRY_RUN="true"; shift 1;
      ;;
    -h|--help)
      print_help; exit 0;
      ;;
    *)
      echo "Option inconnue: $1" >&2
      print_help; exit 1;
      ;;
  esac
done

# Detect Odoo bin if not provided
if [[ -z "$ODOO_BIN_CMD" ]]; then
  if command -v odoo-bin >/dev/null 2>&1; then
    ODOO_BIN_CMD="$(command -v odoo-bin)"
  elif command -v odoo >/dev/null 2>&1; then
    ODOO_BIN_CMD="$(command -v odoo)"
  elif [[ -x "$HOME/src/odoo/odoo-bin" ]]; then
    ODOO_BIN_CMD="$HOME/src/odoo/odoo-bin"
  else
    echo "[ERREUR] Binaire Odoo introuvable. Spécifiez --odoo-bin PATH ou set ODOO_BIN." >&2
    echo "        Ex: --odoo-bin ~/src/odoo/odoo-bin" >&2
    exit 2
  fi
fi

mkdir -p "$CONF_DIR"

# Build addons_path: always include the custom_addons root; include ODOO_ADDONS if provided
ADDONS_PATH="$CUSTOM_ADDONS_DIR"
if [[ -n "$ODOO_ADDONS_PATH" ]]; then
  ADDONS_PATH="$ADDONS_PATH,$ODOO_ADDONS_PATH"
fi

# Write (or overwrite) config file
cat > "$CONF_FILE" <<CFG
[options]
admin_passwd = admin
; DB config (local socket by default)
db_host = False
db_port = False
db_user = odoo
db_password = False
addons_path = $ADDONS_PATH
log_level = info
proxy_mode = True
http_port = $PORT
CFG

EXTRA_ARGS=()
# Demo control: by défaut on désactive les démos pour un démarrage plus rapide
if [[ "$WITH_DEMO" == "false" ]]; then
  EXTRA_ARGS+=("--without-demo=all")
fi

case "$ACTION" in
  init)
    EXTRA_ARGS+=("-i" "sama_conai")
    ;;
  update)
    EXTRA_ARGS+=("-u" "sama_conai")
    ;;
  run)
    :
    ;;
  *)
    echo "[ERREUR] ACTION inconnue: $ACTION" >&2; exit 1;
    ;;
esac

CMD=("$ODOO_BIN_CMD" -c "$CONF_FILE" -d "$DB_NAME" "${EXTRA_ARGS[@]}")

echo "[INFO] Module dir       : $MODULE_DIR"
echo "[INFO] Custom addons dir : $CUSTOM_ADDONS_DIR"
echo "[INFO] Odoo bin          : $ODOO_BIN_CMD"
echo "[INFO] Odoo addons       : ${ODOO_ADDONS_PATH:-<non spécifié>}"
echo "[INFO] Config file       : $CONF_FILE"
echo "[INFO] Database          : $DB_NAME"
echo "[INFO] Port              : $PORT"

if [[ "$DRY_RUN" == "true" ]]; then
  echo "[DRY-RUN] Commande: ${CMD[*]}"
  exit 0
fi

exec "${CMD[@]}"
